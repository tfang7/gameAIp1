﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class AstarInstance : MonoBehaviour {
    public List<Node> open;
    public List<Node> closed;
    public Node end, start;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
